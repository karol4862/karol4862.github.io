self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5d02f2fa36d52ed1e7d7",
    "url": "/assets/css/chunk-2218a33e.bbfb61eb.css"
  },
  {
    "revision": "894d2c1c195c8a2e77fc",
    "url": "/assets/css/chunk-5881af51.bf26a7cd.css"
  },
  {
    "revision": "a952f82d3954422aedfe",
    "url": "/assets/css/chunk-7d8e69b8.23d90689.css"
  },
  {
    "revision": "b7ab645b4fdaefd167cd",
    "url": "/assets/css/chunk-vendors.a34139e5.css"
  },
  {
    "revision": "728b2e8abac339ff2ee5",
    "url": "/assets/css/configuration.030e1295.css"
  },
  {
    "revision": "d245675732543e5cdc54",
    "url": "/assets/css/configurationDictionary.bf26a7cd.css"
  },
  {
    "revision": "80b264acef6b06610759",
    "url": "/assets/css/configurationFiles.9b00c495.css"
  },
  {
    "revision": "1595ff4e21b9e5b7240d",
    "url": "/assets/css/configurationGlobal.5f449363.css"
  },
  {
    "revision": "22f5a8d2fb7a7fffdf62",
    "url": "/assets/css/configurationStaticBlocks.c1c53eae.css"
  },
  {
    "revision": "5aaa3075186c86b1df36",
    "url": "/assets/css/configurationStaticBlocks~manageNotifications~manageProducts~sync.47fd8c9d.css"
  },
  {
    "revision": "48a352d6f6547fcd9150",
    "url": "/assets/css/dashboard.98969d56.css"
  },
  {
    "revision": "039a92422bae49073689",
    "url": "/assets/css/dashboardUserManagement.5cd2fa1d.css"
  },
  {
    "revision": "f2cc5dcdc37bb31b3fe4",
    "url": "/assets/css/home~productDetails.6e3d6aeb.css"
  },
  {
    "revision": "0d4d47cccdf56474d1f2",
    "url": "/assets/css/index.722ec243.css"
  },
  {
    "revision": "33d739a83f653f4afa7e",
    "url": "/assets/css/manageDelivery.bf26a7cd.css"
  },
  {
    "revision": "e0e7f15f66ae93c0295c",
    "url": "/assets/css/manageNotifications.030e1295.css"
  },
  {
    "revision": "33286d3404a1593f9d3a",
    "url": "/assets/css/managePayment.bf26a7cd.css"
  },
  {
    "revision": "4ce7e7c1209d2b35d652",
    "url": "/assets/css/managePointsOfSale.bf26a7cd.css"
  },
  {
    "revision": "d1f836f7bbd827f67191",
    "url": "/assets/css/manageProducts.e1b48b73.css"
  },
  {
    "revision": "355384d46a92c39fe6d9",
    "url": "/assets/css/productOffer.2385f159.css"
  },
  {
    "revision": "05b293ea12d81a53f4a1",
    "url": "/assets/css/regional_settings.f9c9497f.css"
  },
  {
    "revision": "a77e7629eb91fe4b3039",
    "url": "/assets/css/shoppingCart.fed7f10f.css"
  },
  {
    "revision": "4d6cfcba8a8ac78bfa1f",
    "url": "/assets/css/userAuthentication.b4cb7afa.css"
  },
  {
    "revision": "c73eb1ceba3321a80a0aff13ad373cb4",
    "url": "/assets/fonts/Roboto-300.c73eb1ce.woff"
  },
  {
    "revision": "d26871e8149b5759f814fd3c7a4f784b",
    "url": "/assets/fonts/Roboto-300.d26871e8.woff2"
  },
  {
    "revision": "fc84e998bc29b297ea20321e4c90b6ed",
    "url": "/assets/fonts/Roboto-300.fc84e998.ttf"
  },
  {
    "revision": "35b07eb2f8711ae08d1f58c043880930",
    "url": "/assets/fonts/Roboto-400.35b07eb2.woff"
  },
  {
    "revision": "3e1af3ef546b9e6ecef9f3ba197bf7d2",
    "url": "/assets/fonts/Roboto-400.3e1af3ef.ttf"
  },
  {
    "revision": "73f0a88bbca1bec19fb1303c689d04c6",
    "url": "/assets/fonts/Roboto-400.73f0a88b.woff2"
  },
  {
    "revision": "1d6594826615607f6dc860bb49258acb",
    "url": "/assets/fonts/Roboto-500.1d659482.woff"
  },
  {
    "revision": "90d1676003d9c28c04994c18bfd8b558",
    "url": "/assets/fonts/Roboto-500.90d16760.woff2"
  },
  {
    "revision": "d08840599e05db7345652d3d417574a9",
    "url": "/assets/fonts/Roboto-500.d0884059.ttf"
  },
  {
    "revision": "50d75e48e0a3ddab1dd15d6bfb9d3700",
    "url": "/assets/fonts/Roboto-700.50d75e48.woff"
  },
  {
    "revision": "b52fac2bb93c5858f3f2675e4b52e1de",
    "url": "/assets/fonts/Roboto-700.b52fac2b.woff2"
  },
  {
    "revision": "ee7b96fa85d8fdb8c126409326ac2d2b",
    "url": "/assets/fonts/Roboto-700.ee7b96fa.ttf"
  },
  {
    "revision": "de33805c0651f8572e289641629f3745",
    "url": "/assets/fonts/dxiconsmaterial.de33805c.ttf"
  },
  {
    "revision": "e606e2705d866e4ad02ebeb41aada886",
    "url": "/assets/fonts/dxiconsmaterial.e606e270.woff2"
  },
  {
    "revision": "ef3cacd9a0a9db23d49a1d889c3586bc",
    "url": "/assets/fonts/dxiconsmaterial.ef3cacd9.woff"
  },
  {
    "revision": "13685372945d816a2b474fc082fd9aaa",
    "url": "/assets/fonts/fa-brands-400.13685372.ttf"
  },
  {
    "revision": "a06da7f0950f9dd366fc9db9d56d618a",
    "url": "/assets/fonts/fa-brands-400.a06da7f0.woff2"
  },
  {
    "revision": "c1868c9545d2de1cf8488f1dadd8c9d0",
    "url": "/assets/fonts/fa-brands-400.c1868c95.eot"
  },
  {
    "revision": "ec3cfddedb8bebd2d7a3fdf511f7c1cc",
    "url": "/assets/fonts/fa-brands-400.ec3cfdde.woff"
  },
  {
    "revision": "261d666b0147c6c5cda07265f98b8f8c",
    "url": "/assets/fonts/fa-regular-400.261d666b.eot"
  },
  {
    "revision": "c20b5b7362d8d7bb7eddf94344ace33e",
    "url": "/assets/fonts/fa-regular-400.c20b5b73.woff2"
  },
  {
    "revision": "db78b9359171f24936b16d84f63af378",
    "url": "/assets/fonts/fa-regular-400.db78b935.ttf"
  },
  {
    "revision": "f89ea91ecd1ca2db7e09baa2c4b156d1",
    "url": "/assets/fonts/fa-regular-400.f89ea91e.woff"
  },
  {
    "revision": "1ab236ed440ee51810c56bd16628aef0",
    "url": "/assets/fonts/fa-solid-900.1ab236ed.ttf"
  },
  {
    "revision": "a0369ea57eb6d3843d6474c035111f29",
    "url": "/assets/fonts/fa-solid-900.a0369ea5.eot"
  },
  {
    "revision": "b15db15f746f29ffa02638cb455b8ec0",
    "url": "/assets/fonts/fa-solid-900.b15db15f.woff2"
  },
  {
    "revision": "bea989e82b07e9687c26fc58a4805021",
    "url": "/assets/fonts/fa-solid-900.bea989e8.woff"
  },
  {
    "revision": "12d26c285b71d790f4b0c94423ef1f99",
    "url": "/assets/fonts/tinymce-small.12d26c28.eot"
  },
  {
    "revision": "28806940c647cf671bebf4ae0630e570",
    "url": "/assets/fonts/tinymce-small.28806940.ttf"
  },
  {
    "revision": "7e0c88f02dcaf2f78c90b4dc7827b709",
    "url": "/assets/fonts/tinymce-small.7e0c88f0.woff"
  },
  {
    "revision": "06189313e1c7504e1edaa12766c2cfd9",
    "url": "/assets/fonts/tinymce.06189313.eot"
  },
  {
    "revision": "50c955d592e8a54a0e4cb4936d386076",
    "url": "/assets/fonts/tinymce.50c955d5.woff"
  },
  {
    "revision": "db33e7676b65cdbfddbe8cdce17ca068",
    "url": "/assets/fonts/tinymce.db33e767.ttf"
  },
  {
    "revision": "c5cd7f5300576ab4c88202b42f6ded62",
    "url": "/assets/img/ajax-loader.c5cd7f53.gif"
  },
  {
    "revision": "e0d2b7486b532288a980d0cd5d535340",
    "url": "/assets/img/chat-icon.e0d2b748.svg"
  },
  {
    "revision": "6459849cb7031e486cd56958f0f1ae07",
    "url": "/assets/img/close.6459849c.svg"
  },
  {
    "revision": "0cb5a5c0d251c109458c85c6afeffbaa",
    "url": "/assets/img/fa-brands-400.0cb5a5c0.svg"
  },
  {
    "revision": "89ffa3aba80d30ee0a9371b25c968bbb",
    "url": "/assets/img/fa-regular-400.89ffa3ab.svg"
  },
  {
    "revision": "ec763292e583294612f124c0b0def500",
    "url": "/assets/img/fa-solid-900.ec763292.svg"
  },
  {
    "revision": "d4a4d7b033f5ad8d72611239519d2862",
    "url": "/assets/img/famfamfam-flags.d4a4d7b0.png"
  },
  {
    "revision": "b6e6159efa7453d7abdc506ca5e1d377",
    "url": "/assets/img/file.b6e6159e.svg"
  },
  {
    "revision": "fd42f6cbf2d662175f36d84895fdfba5",
    "url": "/assets/img/loading.fd42f6cb.gif"
  },
  {
    "revision": "a26ebdf90c76dac2de70b894d42252f4",
    "url": "/assets/img/logo-no-bg.a26ebdf9.svg"
  },
  {
    "revision": "bb69d6f84cdee7696f44374921d832c5",
    "url": "/assets/img/louis.bb69d6f8.png"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/assets/img/slick.f97e3bbf.svg"
  },
  {
    "revision": "a2a1f732cc34764c684ed521c6f3327c",
    "url": "/assets/img/tinymce-small.a2a1f732.svg"
  },
  {
    "revision": "d031f47facf4331979b6f9fbac3187ef",
    "url": "/assets/img/tinymce.d031f47f.svg"
  },
  {
    "revision": "13084d3d6d5ddaa8e205",
    "url": "/assets/js/blog.123c647a.js"
  },
  {
    "revision": "5d02f2fa36d52ed1e7d7",
    "url": "/assets/js/chunk-2218a33e.8c8afb01.js"
  },
  {
    "revision": "e3cbea54e32e71652c18",
    "url": "/assets/js/chunk-2d0cc288.97c053d2.js"
  },
  {
    "revision": "9ae1e03bd4f7ef117518",
    "url": "/assets/js/chunk-2d0d70fe.3d5ad271.js"
  },
  {
    "revision": "c8d51a88deaacfff918e",
    "url": "/assets/js/chunk-2d22c341.fa9c486f.js"
  },
  {
    "revision": "027578a047584440a55f",
    "url": "/assets/js/chunk-2d22ddc5.b1664163.js"
  },
  {
    "revision": "894d2c1c195c8a2e77fc",
    "url": "/assets/js/chunk-5881af51.95692337.js"
  },
  {
    "revision": "96e63a4dad29b34b803f",
    "url": "/assets/js/chunk-7caf1105.b65b3881.js"
  },
  {
    "revision": "a952f82d3954422aedfe",
    "url": "/assets/js/chunk-7d8e69b8.0f1e4d91.js"
  },
  {
    "revision": "7e81ac6ac9bf8d8a57f3",
    "url": "/assets/js/chunk-a7a61610.5e61c66b.js"
  },
  {
    "revision": "97c1526b0a757ac09625",
    "url": "/assets/js/chunk-c6d990ba.bafae9f4.js"
  },
  {
    "revision": "8cc499482a9108457ab1",
    "url": "/assets/js/chunk-e180284a.ce3e839f.js"
  },
  {
    "revision": "b7ab645b4fdaefd167cd",
    "url": "/assets/js/chunk-vendors.6aa04be5.js"
  },
  {
    "revision": "728b2e8abac339ff2ee5",
    "url": "/assets/js/configuration.e59ef704.js"
  },
  {
    "revision": "d245675732543e5cdc54",
    "url": "/assets/js/configurationDictionary.d346ef20.js"
  },
  {
    "revision": "80b264acef6b06610759",
    "url": "/assets/js/configurationFiles.aaf45c1a.js"
  },
  {
    "revision": "1595ff4e21b9e5b7240d",
    "url": "/assets/js/configurationGlobal.765ae1cf.js"
  },
  {
    "revision": "1799e59910fd29cbaa54",
    "url": "/assets/js/configurationNotifyAvailability.d797587f.js"
  },
  {
    "revision": "22f5a8d2fb7a7fffdf62",
    "url": "/assets/js/configurationStaticBlocks.87bfde7e.js"
  },
  {
    "revision": "5aaa3075186c86b1df36",
    "url": "/assets/js/configurationStaticBlocks~manageNotifications~manageProducts~sync.ae51c3e3.js"
  },
  {
    "revision": "627dae3a083d2f302bda",
    "url": "/assets/js/configurationWarehouse.3269409f.js"
  },
  {
    "revision": "48a352d6f6547fcd9150",
    "url": "/assets/js/dashboard.ea657aef.js"
  },
  {
    "revision": "d40f22edc301d76acf16",
    "url": "/assets/js/dashboardAccount.723d41be.js"
  },
  {
    "revision": "394a81b458ee405f2fb2",
    "url": "/assets/js/dashboardHome.e02a49fe.js"
  },
  {
    "revision": "c9483752d6564c230c88",
    "url": "/assets/js/dashboardOrder.199d28b6.js"
  },
  {
    "revision": "15d415efbb55a2a7bb65",
    "url": "/assets/js/dashboardRoleManagement.a30a3050.js"
  },
  {
    "revision": "039a92422bae49073689",
    "url": "/assets/js/dashboardUserManagement.806246e9.js"
  },
  {
    "revision": "5a82495ea2d1c01632b1",
    "url": "/assets/js/dashboard~home~productDetails.ac2146c4.js"
  },
  {
    "revision": "583b47d5d2d1b9e7584f",
    "url": "/assets/js/error.1bb10950.js"
  },
  {
    "revision": "1f1d1aa91955cedf2dd2",
    "url": "/assets/js/favorite.3cb1f4f4.js"
  },
  {
    "revision": "bacf038558aadecf9387",
    "url": "/assets/js/home.e9cc3a88.js"
  },
  {
    "revision": "f2cc5dcdc37bb31b3fe4",
    "url": "/assets/js/home~productDetails.3a94f857.js"
  },
  {
    "revision": "0d4d47cccdf56474d1f2",
    "url": "/assets/js/index.548d6aa4.js"
  },
  {
    "revision": "33d739a83f653f4afa7e",
    "url": "/assets/js/manageDelivery.37874068.js"
  },
  {
    "revision": "e0e7f15f66ae93c0295c",
    "url": "/assets/js/manageNotifications.5fd39207.js"
  },
  {
    "revision": "33286d3404a1593f9d3a",
    "url": "/assets/js/managePayment.ec181d60.js"
  },
  {
    "revision": "4ce7e7c1209d2b35d652",
    "url": "/assets/js/managePointsOfSale.18c18f82.js"
  },
  {
    "revision": "d1f836f7bbd827f67191",
    "url": "/assets/js/manageProducts.eafe2251.js"
  },
  {
    "revision": "82a97e6f77dc3098aaee",
    "url": "/assets/js/orderConfirmation.bbee768e.js"
  },
  {
    "revision": "7fed2edcfd55d5e76354",
    "url": "/assets/js/productDetails.8696df41.js"
  },
  {
    "revision": "355384d46a92c39fe6d9",
    "url": "/assets/js/productOffer.a546d47f.js"
  },
  {
    "revision": "05b293ea12d81a53f4a1",
    "url": "/assets/js/regional_settings.ff1daa6e.js"
  },
  {
    "revision": "a77e7629eb91fe4b3039",
    "url": "/assets/js/shoppingCart.3d7a0627.js"
  },
  {
    "revision": "8bac191546f0778477e0",
    "url": "/assets/js/sync.49fa9261.js"
  },
  {
    "revision": "4d6cfcba8a8ac78bfa1f",
    "url": "/assets/js/userAuthentication.11f73c28.js"
  },
  {
    "revision": "ed95cde75c68b88180e0182b7044c6c4",
    "url": "/index.html"
  },
  {
    "revision": "62203c1b52bdf488dcee02f6112494a7",
    "url": "/manifest.json"
  }
]);